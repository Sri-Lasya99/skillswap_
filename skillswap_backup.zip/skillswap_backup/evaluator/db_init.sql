DROP TABLE IF EXISTS
    badges,
    points_history,
    login_streaks,
    content_upvotes,
    content_vote_history,
    feedback_points,
    published_content,
    user_stats,
    user_info,
    messages;

CREATE TABLE user_info (
    user_id SERIAL PRIMARY KEY,
    age INT,
    gender VARCHAR(10),
    city VARCHAR(100),
    skilled VARCHAR(255),
    interest VARCHAR(255)
);

CREATE TABLE user_stats (
    user_id INT PRIMARY KEY REFERENCES user_info(user_id),
    points INT DEFAULT 0,
    time_total INT,
    logins_week INT,
    highest_streak INT
);

CREATE TABLE feedback_points (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES user_info(user_id),
    points INT,
    skill VARCHAR(100),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE content_upvotes (
    user_id INT REFERENCES user_info(user_id),
    content_id INT REFERENCES published_content(id),
    created_at TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY(user_id, content_id)
);

CREATE TABLE content_vote_history (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES user_info(user_id),
    content_id INT,
    action VARCHAR(10), -- 'upvote' or 'unvote'
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE login_streaks (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES user_info(user_id),
    streak_days INT,
    points INT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE points_history (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES user_info(user_id),
    source VARCHAR(50),
    points INT,
    skill VARCHAR(100),
    recorded_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE badges (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES user_info(user_id),
    badge VARCHAR(50),
    awarded_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE messages (
    id SERIAL PRIMARY KEY,
    sender_id INT REFERENCES user_info(user_id),
    receiver_id INT REFERENCES user_info(user_id),
    content TEXT,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE published_content (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES user_info(user_id),
    title TEXT,
    url TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);