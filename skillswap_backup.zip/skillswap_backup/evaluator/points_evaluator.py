import os
import psycopg2
from datetime import datetime
import requests

WEIGHTS = {'feedback': 15, 'upvote': 25, 'streak': 10}
BADGES = [(1000, 'Gold'), (500, 'Silver'), (100, 'Bronze')]
DSN = "postgresql://neondb_owner:npg_go1ziJG5VcKx@" \
      "ep-round-lab-a49md6ql-pooler.us-east-1.aws.neon.tech/" \
      "neondb?sslmode=require"
GEMINI_KEY = "AIzaSyCa9prYeLFZG5s5NFqU1SvXlVIFb-Tyilw"

if not GEMINI_KEY:
    raise EnvironmentError("GEMINI_KEY is not set")


def process_event(user_id, source, skill='', extra=1):
    pts = WEIGHTS.get(source, 0) * extra
    tbl_map = {
        'feedback': 'feedback_points',
        'upvote': 'content_upvotes',
        'streak': 'login_streaks'
    }
    tbl = tbl_map.get(source)
    if not tbl:
        raise ValueError("Invalid event source")

    try:
        with psycopg2.connect(DSN) as conn:
            with conn.cursor() as cur:
                if source == 'streak':
                    cur.execute(
                        f"INSERT INTO {tbl}(user_id, streak_days, points, created_at) "
                        "VALUES (%s, %s, %s, NOW())",
                        (user_id, extra, pts)
                    )
                else:
                    cur.execute(
                        f"INSERT INTO {tbl}(user_id, points, skill, created_at) "
                        "VALUES (%s, %s, %s, NOW())",
                        (user_id, pts, skill)
                    )

                cur.execute(
                    "UPDATE user_stats SET points = points + %s WHERE user_id = %s",
                    (pts, user_id)
                )

                cur.execute(
                    "INSERT INTO points_history(user_id, source, points, skill, recorded_at) "
                    "VALUES (%s, %s, %s, %s, NOW())",
                    (user_id, source, pts, skill)
                )

                # Award badges if applicable
                cur.execute("SELECT points FROM user_stats WHERE user_id = %s", (user_id,))
                user_points = cur.fetchone()[0]

                for thresh, badge in BADGES:
                    if user_points >= thresh:
                        cur.execute(
                            "SELECT badge FROM badges WHERE user_id = %s AND badge = %s",
                            (user_id, badge)
                        )
                        if not cur.fetchone():
                            cur.execute(
                                "INSERT INTO badges(user_id, badge, awarded_at) VALUES (%s, %s, NOW())",
                                (user_id, badge)
                            )
                        break

    except Exception as e:
        print(f"Database error: {e}")


def summarize_media(url: str) -> str:
    headers = {'Authorization': f'Bearer {GEMINI_KEY}'}
    payload = {'url': url}

    try:
        r = requests.post('https://gemini.api/summarize', headers=headers, json=payload)
        r.raise_for_status()
        return r.json().get('summary', '')
    except Exception as e:
        print(f"API error: {e}")
        return ''
