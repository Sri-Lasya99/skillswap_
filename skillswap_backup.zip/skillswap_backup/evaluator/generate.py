import pandas as pd
import numpy as np
from sqlalchemy import create_engine

engine = create_engine(
    "postgresql://neondb_owner:npg_go1ziJG5VcKx@"
    "ep-round-lab-a49md6ql-pooler.us-east-1.aws.neon.tech/"
    "neondb?sslmode=require"
)

# synthesize events: feedback, upvotes, streaks

def gen_events(user_count=500):
    np.random.seed(1)
    ids = np.arange(1, user_count+1)
    skills = [
        "AI","Data Science","Web Dev","Mobile App","Cybersecurity",
        "ML","Game Dev","UI/UX","Cloud","Blockchain"
    ]
    fb, up, st = [], [], []
    for uid in ids:
        for _ in range(np.random.randint(1,5)):
            fb.append((uid, np.random.randint(5,20), np.random.choice(skills)))
        for _ in range(np.random.randint(1,5)):
            up.append((uid, np.random.randint(10,30), np.random.choice(skills)))
        days = np.random.randint(1,15)
        st.append((uid, days, days*10))
    return (
        pd.DataFrame(fb, columns=['user_id','points','skill']),
        pd.DataFrame(up, columns=['user_id','points','skill']),
        pd.DataFrame(st, columns=['user_id','streak_days','points'])
    )

# synthesize published content for first 50 users
def gen_content(user_count=50, each=3):
    np.random.seed(2)
    rows = []
    for uid in range(1, user_count+1):
        for i in range(each):
            title = f"Content {i+1} by User {uid}"
            url = f"https://www.google.com/search?q=content+{uid}+{i+1}"
            rows.append((uid, title, url))
    return pd.DataFrame(rows, columns=['user_id','title','url'])

# synthesize initial upvotes and history for content

def gen_content_votes(content_df, user_count=500):
    np.random.seed(3)
    votes, history = [], []
    for cid in content_df.index+1:
        upvoters = np.random.choice(range(1, user_count+1), size=3, replace=False)
        for uid in upvoters:
            votes.append((uid, cid))
            history.append((uid, cid, 'upvote'))
            if np.random.rand()<0.2:
                history.append((uid, cid, 'unvote'))
    return (
        pd.DataFrame(votes, columns=['user_id','content_id']),
        pd.DataFrame(history, columns=['user_id','content_id','action'])
    )

# load all generated tables

def load():
    fb, up, st = gen_events()
    fb.to_sql('feedback_points', engine, if_exists='replace', index=False)
    up.to_sql('content_upvotes', engine, if_exists='replace', index=False)
    st.to_sql('login_streaks', engine, if_exists='replace', index=False)

    history = []
    for _,r in fb.iterrows(): history.append((r.user_id,'feedback',r.points,r.skill))
    for _,r in up.iterrows(): history.append((r.user_id,'upvote',r.points,r.skill))
    for _,r in st.iterrows(): history.append((r.user_id,'streak',r.points,''))
    pd.DataFrame(history, columns=['user_id','source','points','skill'])\
        .to_sql('points_history', engine, if_exists='replace', index=False)

    content_df = gen_content()
    content_df.to_sql('published_content', engine, if_exists='replace', index=False)

    votes_df, vote_hist = gen_content_votes(content_df)
    votes_df.to_sql('content_upvotes', engine, if_exists='append', index=False)
    vote_hist.to_sql('content_vote_history', engine, if_exists='replace', index=False)

    msgs = gen_events()[0]  # reuse ids
    # placeholder messages generation
    print("Loaded all events, content, votes, and history.")

if __name__=='__main__':
    load()