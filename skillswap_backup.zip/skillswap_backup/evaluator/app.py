from fastapi import FastAPI, HTTPException
from points_evaluator import process_event, summarize_media
from fastapi.middleware.cors import CORSMiddleware
import psycopg2

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DSN = "postgresql://neondb_owner:npg_go1ziJG5VcKx@" \
      "ep-round-lab-a49md6ql-pooler.us-east-1.aws.neon.tech/" \
      "neondb?sslmode=require"
psycopg2.connect(DSN)


@app.post('/feedback/')
def feedback(user_id: int, skill: str, count: int = 1):
    process_event(user_id, 'feedback', skill, count)
    return {'status': 'ok'}

@app.post('/upvote/')
def upvote(user_id: int, skill: str, count: int = 1):
    process_event(user_id, 'upvote', skill, count)
    return {'status': 'ok'}

@app.post('/login_streak/')
def login_streak(user_id: int, days: int):
    process_event(user_id, 'streak', '', days)
    return {'status': 'ok'}

@app.post('/content/publish/')
def publish_content(user_id: int, title: str, url: str):
    try:
        conn = psycopg2.connect(DSN)
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO published_content(user_id,title,url,created_at) "
            "VALUES(%s,%s,%s,NOW()) RETURNING id",
            (user_id, title, url)
        )
        cid = cur.fetchone()[0]
        conn.commit()
        return {'content_id': cid}
    except Exception as e:
        raise HTTPException(500, f"DB error: {e}")
    finally:
        cur.close(); conn.close()

@app.post('/content/upvote/')
def content_upvote(user_id: int, content_id: int):
    try:
        conn = psycopg2.connect(DSN)
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO content_upvotes(user_id,content_id,created_at) "
            "VALUES(%s,%s,NOW())",
            (user_id, content_id)
        )
        cur.execute(
            "INSERT INTO content_vote_history(user_id,content_id,action,created_at) "
            "VALUES(%s,%s,'upvote',NOW())",
            (user_id, content_id)
        )
        conn.commit()
        return {'status': 'upvoted'}
    except Exception as e:
        raise HTTPException(500, f"DB error: {e}")
    finally:
        cur.close(); conn.close()

@app.post('/content/unvote/')
def content_unvote(user_id: int, content_id: int):
    try:
        conn = psycopg2.connect(DSN)
        cur = conn.cursor()
        cur.execute(
            "DELETE FROM content_upvotes WHERE user_id=%s AND content_id=%s",
            (user_id, content_id)
        )
        cur.execute(
            "INSERT INTO content_vote_history(user_id,content_id,action,created_at) "
            "VALUES(%s,%s,'unvote',NOW())",
            (user_id, content_id)
        )
        conn.commit()
        return {'status': 'unvoted'}
    except Exception as e:
        raise HTTPException(500, f"DB error: {e}")
    finally:
        cur.close(); conn.close()

@app.get('/summarize/')
def summarize(url: str):
    summary = summarize_media(url)
    return {'summary': summary}
