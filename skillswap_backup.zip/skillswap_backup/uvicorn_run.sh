#!/usr/bin/env bash
uvicorn main:app --host 0.0.0.0 --port 8000 &
uvicorn evaluator.app:app --host 0.0.0.0 --port8001&
wait