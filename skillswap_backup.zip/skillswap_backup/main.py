# main.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pandas as pd, joblib
import numpy as np
from sklearn.neighbors import NearestNeighbors
from typing import Any, Dict, List

app = FastAPI()

# --- Load artifacts ---
model: NearestNeighbors = joblib.load("ml_pipeline/models/model.pkl")
processed_df: pd.DataFrame = joblib.load("ml_pipeline/models/data.pkl")
user_ids: List[int] = joblib.load("ml_pipeline/models/user_id.pkl")
initial_df: pd.DataFrame = joblib.load("ml_pipeline/models/initial_data.pkl")

# map user_id → row index in processed_df
id_to_idx = {uid: idx for idx, uid in enumerate(user_ids)}

class Recommendation(BaseModel):
    matched_user_id: Any  
    distance: Any           
    profile: Dict[str,Any]  

class Response(BaseModel):
    skill_i_have: str
    skill_i_want: str
    recommendations: List[Recommendation]

@app.get("/recommend/{user_id}", response_model=Response)
def recommend_by_id(user_id: int, top_k: int = 3):
    if user_id not in id_to_idx:
        raise HTTPException(status_code=404, detail=f"user_id {user_id} not found")
    
    user_row = initial_df[initial_df["user_id"] == user_id]
    if user_row.empty:
        raise HTTPException(status_code=404, detail="User data missing")
    user_row = user_row.iloc[0]

    skilled_list = [s.strip() for s in str(user_row["skilled"]).split(",") if s.strip()]
    interest_list = [s.strip() for s in str(user_row["intrest"]).split(",") if s.strip()]
    if not skilled_list or not interest_list:
        raise HTTPException(status_code=400, detail="User must have at least one skill and one interest")

    skill_i_have = skilled_list[0]
    skill_i_want = interest_list[0]
    user_points = user_row["points"]

    def wants_skill(df, skill): return df["intrest"].str.contains(fr"\b{skill}\b", case=False, na=False)
    def has_skill(df, skill): return df["skilled"].str.contains(fr"\b{skill}\b", case=False, na=False)
    def close_points(df, pts): return df["points"].sub(pts).abs().le(1000)

    mask = (
        wants_skill(initial_df, skill_i_have) &
        has_skill(initial_df, skill_i_want) &
        close_points(initial_df, user_points)
    )
    candidates = initial_df[mask & (initial_df["user_id"] != user_id)]
    if candidates.empty:
        return Response(
            skill_i_have=skill_i_have,
            skill_i_want=skill_i_want,
            recommendations=[
                Recommendation(matched_user_id=None, distance="not found a recommendation", profile={})
                for _ in range(top_k)
            ]
        )

    user_idx = id_to_idx[user_id]
    user_vec = processed_df.values[user_idx: user_idx+1]
    distances, indices = model.kneighbors(user_vec, n_neighbors=len(user_ids))
    dists = distances[0]
    idxs = indices[0]

    recs: List[Recommendation] = []
    for dist, nbr_idx in zip(dists, idxs):
        nbr_id = user_ids[nbr_idx]
        if nbr_id == user_id:
            continue
        if nbr_id not in set(candidates["user_id"]):
            continue

        # --- mutual match check ---
        if nbr_id not in id_to_idx:
            continue
        nbr_vec = processed_df.values[nbr_idx: nbr_idx+1]
        rev_dists, rev_indices = model.kneighbors(nbr_vec, n_neighbors=top_k)
        rev_recs_ids = [user_ids[i] for i in rev_indices[0]]
        if user_id not in rev_recs_ids:
            continue
        # --- end mutual match check ---

        profile = initial_df[initial_df["user_id"] == nbr_id].iloc[0].to_dict()
        recs.append(Recommendation(
            matched_user_id=int(nbr_id),
            distance=round(float(dist), 3),
            profile=profile
        ))
        if len(recs) >= top_k:
            break

    while len(recs) < top_k:
        recs.append(Recommendation(
            matched_user_id=None,
            distance="not found a recommendation",
            profile={}
        ))

    return Response(
        skill_i_have=skill_i_have,
        skill_i_want=skill_i_want,
        recommendations=recs
    )

if __name__ == "__main__":
    import uvicorn, sys
    if len(sys.argv) == 2:
        uid = int(sys.argv[1])
        resp = recommend_by_id(uid)
        print(resp.json(indent=2))
    else:
        uvicorn.run("recommender:app", host="127.0.0.1", port=8000, reload=True)

