import pandas as pd
import numpy as np
from sqlalchemy import create_engine

user_count = 500
user_id = np.arange(1, user_count + 1)

np.random.seed(1)
age = np.random.randint(18, 70, size=user_count)
gender = np.random.choice(['Male', 'Female'], size=user_count)
cities = np.random.choice(["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai",
                           "Kolkata", "Pune", "Ahmedabad", "Jaipur", "Lucknow"], size=user_count)
interests = ["Artificial Intelligence", "Data Science", "Web Development", "Mobile App Development", "Cybersecurity",
             "Machine Learning", "Game Development", "UI/UX Design", "Cloud Computing", "Blockchain"]
skills = interests.copy()

user_interest = []
user_skilled = []

for _ in range(user_count):
    skill = ",".join(np.random.choice(skills, size=np.random.randint(1, 3), replace=False))
    interest = ",".join(np.random.choice(interests, size=np.random.randint(1, 5), replace=False))
    user_skilled.append(skill)
    user_interest.append(interest)

user_info = pd.DataFrame({
    "user_id": user_id,
    "age": age,
    "gender": gender,
    "cities": cities,
    "skilled": user_skilled,
    "intrest": user_interest
})

time_total = np.random.randint(0, 500, size=user_count)
logins_inweek = np.random.randint(0, 7, size=user_count)
highest_streak = np.random.randint(0, 50, size=user_count)
points = np.random.randint(0, 2000, size=user_count)

user_stats = pd.DataFrame({
    "user_id": user_id,
    "points": points,
    "time_total": time_total,
    "logins_week": logins_inweek,
    "highest_streak": highest_streak
})

db_url = "postgresql://neondb_owner:npg_go1ziJG5VcKx@ep-round-lab-a49md6ql-pooler.us-east-1.aws.neon.tech/neondb?sslmode=require"
engine = create_engine(db_url)

user_info.to_sql("user_info", engine, if_exists="replace", index=False)
user_stats.to_sql("user_stats", engine, if_exists="replace", index=False)

print("Data inserted successfully!")
