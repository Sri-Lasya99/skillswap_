import pandas as pd
from sklearn.preprocessing import StandardScaler, MultiLabelBinarizer, OneHotEncoder
from pathlib import Path
import joblib
import logging

# Setup logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
logger.addHandler(handler)
BASE_DIR = Path(__file__).resolve().parent.parent  # project root
INGESTED_PATH = BASE_DIR / "data" / "ingested" / "data.csv"
PROCESSED_DIR = BASE_DIR / "data" / "processed"
MODELS_DIR = BASE_DIR / "models"
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)


def load_data(path: Path) -> pd.DataFrame:
    if not path.exists():
        logger.error(f"Ingested data not found at {path}")
        raise FileNotFoundError(path)
    df = pd.read_csv(path)
    logger.debug("Data loaded successfully.")
    return df


def handling_nums(df: pd.DataFrame) -> pd.DataFrame:
    ";""Handle duplicates, missing values, outliers, and scale numeric features."""
    logger.debug("Started handling numeric features.")

    if 'user_id' in df.columns:
        user_ids = df['user_id'].unique()
        joblib.dump(user_ids, MODELS_DIR / "user_id.pkl")
        df = df.drop('user_id', axis=1).reset_index(drop=True)
 
    num_cols = df.select_dtypes(include='number').columns.tolist()

    for col in num_cols:
        if df[col].isnull().any():
            median = df[col].median()
            df[col].fillna(median, inplace=True)
    logger.debug("Filled numeric missing values.")

    def remove_outliers(series):
        q1, q3 = series.quantile([0.25, 0.75])
        iqr = q3 - q1
        return series[(series >= q1 - 1.5 * iqr) & (series <= q3 + 1.5 * iqr)]

    mask = pd.Series(True, index=df.index)
    for col in num_cols:
        col_mask = remove_outliers(df[col]).index
        mask &= df.index.isin(col_mask)
    df = df.loc[mask].reset_index(drop=True)
    logger.debug("Removed numeric outliers.")


    scaler = StandardScaler()
    df[num_cols] = scaler.fit_transform(df[num_cols])
    joblib.dump(scaler, MODELS_DIR / "scaler.pkl")
    logger.debug("Applied and saved StandardScaler.")

    return df


def handling_cats(df: pd.DataFrame) -> pd.DataFrame:
    """Handle missing, encode categorical features."""
    logger.debug("Started handling categorical features.")
    cat_cols = df.select_dtypes(include='object').columns.tolist()
    for col in cat_cols:
        if df[col].isnull().any():
            mode_val = df[col].mode()[0]
            df[col].fillna(mode_val, inplace=True)
    logger.debug("Filled categorical missing values.")

    if 'gender' in df.columns:
        ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
        gender_arr = ohe.fit_transform(df[['gender']])
        gender_cols = ohe.get_feature_names_out(['gender'])
        df = df.drop('gender', axis=1)
        df[gender_cols] = gender_arr
        joblib.dump(ohe, MODELS_DIR / "ohe_gender.pkl")
        logger.debug("Encoded and saved gender with OneHotEncoder.")

    list_fields = [col for col in ['cities', 'skilled', 'intrest'] if col in df.columns]
    for col in list_fields:
        mlb = MultiLabelBinarizer()
        df[col] = df[col].astype(str).apply(lambda x: [i.strip() for i in x.split(',') if i.strip()])
        encoded = mlb.fit_transform(df[col])
        mlb_cols = [f"{col}_{cls}" for cls in mlb.classes_]
        df = df.drop(col, axis=1)
        df[mlb_cols] = encoded
        joblib.dump(mlb, MODELS_DIR / f"mlb_{col}.pkl")
        logger.debug(f"Encoded and saved {col} with MultiLabelBinarizer.")

    logger.debug("Completed categorical preprocessing.")
    return df


def save_data(df: pd.DataFrame):
    processed_file = PROCESSED_DIR / "processed_data.csv"
    df.to_csv(processed_file, index=False)
    joblib.dump(df,MODELS_DIR/"data.pkl")
    joblib.dump(df.columns.tolist(), MODELS_DIR / "feature_columns.pkl")
    logger.debug(f"Processed data saved to {processed_file}")

def main():
    df = load_data(INGESTED_PATH)
    df = handling_nums(df)
    df = handling_cats(df)
    save_data(df)
main()
