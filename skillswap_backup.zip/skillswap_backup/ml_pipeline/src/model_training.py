import mlflow
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import silhouette_score
import yaml
import pandas as pd
import joblib
import logging
import os 


logger=logging.getLogger("training")
logger.setLevel(logging.DEBUG)
logger.propagate=False 
formatter=logging.Formatter("%(asctime)s-%(levelname)s-%(message)s") 
console_handler=logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)

def load_data(data_path:str):
    try:
        data_df=pd.read_csv(data_path)
        logger.debug("data got successfully loaded")
        return data_df
    except Exception as e:
        logger.error("unexcepted error occured : %s",e)
        raise
def load_params(params_path:str):
    try:
        with open(params_path, 'r') as file:
            params=yaml.safe_load(file)
            logger.debug("params got successfully loaded")
            return params['knn']
    except Exception as e:
        logger.error("unexcepted error occured : %s",e)
        raise

def save_model(model, model_path):
    try:
        model_url=os.path.join(model_path,"model.pkl")
        data_url=os.path.join(model_path,"data.csv")
        joblib.dump(model, model_url)
        logger.debug("model got successfully saved")
    except Exception as e:
        logger.error("unexcepted error occured : %s",e)
        raise

def train_knn(data_df:pd.DataFrame,params):
    try:
        logger.debug("Training of model started")
        best_score =float('inf')
        best_model = None
        best_k = None

        mlflow.set_experiment("KNN_User_Recommendations")
        with mlflow.start_run():
            logger.debug("experiments started")
            for k in range(params['min_k'], params['max_k'] + 1):
                model = NearestNeighbors(n_neighbors=k, metric=params['metric'])
                model.fit(data_df)
                neighbors = model.kneighbors(data_df, return_distance=True)
                distances = neighbors[0]
                avg_distance = distances.mean()

                mlflow.log_metric(f"avg_distance_k_{k}", avg_distance)

                if avg_distance < best_score:
                    best_score = avg_distance
                    best_model = model
                    best_k = k
            logger.debug("experiments ended")
            mlflow.log_param("best_k", best_k)
            mlflow.log_param("metric", params['metric'])
            mlflow.log_metric("best_score", best_score)
            logging.debug("params and metrics are logged")
            logging.debug("training completed")
            return best_model
    except Exception as e:
        logger.error("unexcepted error occured : %s",e)
        raise

    
def main():
    data_path="ml_pipeline/data/processed/processed_data.csv"
    param_path="ml_pipeline/params.yaml"
    model_path="ml_pipeline/models"
    data_df=load_data(data_path)
    params=load_params(param_path)
    best_model=train_knn(data_df,params)
    save_model(best_model,model_path)
main()