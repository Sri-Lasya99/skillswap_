import pandas as pd
import logging
import os
import joblib
from sqlalchemy import create_engine

# Setup logging
logger = logging.getLogger("data_ingestion_db")
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

if not logger.handlers:
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

# Database connection string
DATABASE_URL = "postgresql://neondb_owner:npg_go1ziJG5VcKx@ep-round-lab-a49md6ql-pooler.us-east-1.aws.neon.tech/neondb?sslmode=require"

def load_data_from_db():
    """ Load data from PostgreSQL tables """
    try:
        engine = create_engine(DATABASE_URL)
        user_info = pd.read_sql_table("user_info", con=engine)
        user_stats = pd.read_sql_table("user_stats", con=engine)
        logger.debug("Successfully loaded data from database")
        return user_info, user_stats
    except Exception as e:
        logger.error("Error loading data from database: %s", e)
        raise

def preprocessing(infos: pd.DataFrame, stats: pd.DataFrame):
    try:
        data = pd.merge(infos, stats, on='user_id')
        logger.debug("Data merged successfully")
        return data
    except Exception as e:
        logger.error("Error merging data: %s", e)
        raise

def save_data(df_data: pd.DataFrame, data_path: str):
    try:
        ingested_path = os.path.join(data_path, "ingested")
        os.makedirs(ingested_path, exist_ok=True)

        train_path = os.path.join(ingested_path, "data.csv")
        df_data.to_csv(train_path, index=False)

        models_path = "ml_pipeline/models"
        os.makedirs(models_path, exist_ok=True)

        joblib.dump(df_data['user_id'].tolist(), os.path.join(models_path, "user_id.pkl"))
        joblib.dump(df_data, os.path.join(models_path, "initial_data.pkl"))

        logger.debug("Data saved successfully")

    except Exception as e:
        logger.error("Error saving data: %s", e)
        raise

def main():
    try:
        logger.debug("Started pipeline")
        data_url = r"C:/Users/ShivaSai/OneDrive/Desktop/skillswap_backup/ml_pipeline/data"
        df_info, df_stats = load_data_from_db()
        df_data = preprocessing(df_info, df_stats)
        save_data(df_data, data_path=data_url)
        logger.debug("Pipeline completed")
    except Exception as e:
        logger.error("Unexpected error: %s", e)
        raise

main()
