const USER_ID = 5;  // Example User ID

// Fetch user profile and recommendations
async function loadData() {
  try {
    // Recommendations from main.py
    const recRes = await fetch(`/recommend/${USER_ID}`);
    const recData = await recRes.json();

    document.getElementById('user-name').textContent =
      (recData.recommendations[0]?.profile?.name) || `User ${USER_ID}`;
    document.getElementById('user-skills').textContent = recData.skill_i_have || '';
    document.getElementById('user-interests').textContent = recData.skill_i_want || '';
    document.getElementById('user-points').textContent =
      (recData.recommendations[0]?.profile?.points) || '0';

    document.getElementById('recs-list').innerHTML = recData.recommendations
      .map(r => `<li>User ${r.matched_user_id} — Distance: ${r.distance}</li>`)
      .join('');

    // Messages from evaluator/app.py
    const msgRes = await fetch(`/messages?user1=${USER_ID}&user2=${USER_ID}`);
    const msgs = await msgRes.json();
    document.getElementById('msg-list').innerHTML = msgs
      .map(m => `<li><strong>${m.sender_id}:</strong> ${m.content} <em>${new Date(m.created_at).toLocaleString()}</em></li>`)
      .join('');
  } catch (error) {
    console.error('Load error:', error);
  }
}

// Generate content summary
document.getElementById('btn-summary').addEventListener('click', async () => {
  try {
    const res = await fetch(`/summarize?url=https://example.com`);
    const data = await res.json();
    document.getElementById('summary-text').textContent = data.summary;
  } catch (error) {
    console.error('Summary error:', error);
  }
});

// Send a new message
document.getElementById('msg-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const receiverId = document.getElementById('receiver-id').value;
  const content = document.getElementById('msg-content').value;
  try {
    await fetch('/message/send/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sender_id: USER_ID, receiver_id: parseInt(receiverId), content })
    });
    document.getElementById('msg-content').value = '';
    loadData(); // reload messages
  } catch (error) {
    console.error('Send message error:', error);
  }
});

// Initialize on page load
window.onload = loadData;
